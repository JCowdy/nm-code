const logger = require('./logger');

describe('Logger', function() {
    it('does something', () => {

    })
});
